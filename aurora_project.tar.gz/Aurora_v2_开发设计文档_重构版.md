# Aurora v2：基于 Codex、Fact–Intent 黑板与统一 MCP 工具总线的开发设计文档

> 版本：v0.2  
> 日期：2026-07-15  
> 状态：架构设计重构稿

## 0. 文档说明

本文档是在前一版架构草案基础上的重新设计稿，统一吸收了对 Cairn、BreachWeave、Codex Harness、黑板上下文管理、Worker/Agent 关系、Manager–Observer–Solver 模型以及 MCP 工具总线的讨论结果。

本版本作出一个明确决策：Aurora v2 不再使用 LangGraph 作为全局编排框架。项目级执行由 Fact–Intent 黑板、数据库状态机、事件驱动调度器和 Codex Worker Runtime 共同完成。

| 项目 | 内容 |
| --- | --- |
| 项目名称 | Aurora |
| 文档版本 | v0.2 |
| 目标场景 | CTF、授权渗透测试、漏洞研究、安全分析自动化 |
| 核心运行时 | Codex App Server / Codex Agent Loop |
| 全局编排 | 自研 Fact–Intent 图 + Scheduler，不使用 LangGraph |
| 工具接入 | Worker 可见工具全部通过统一 MCP Tool Gateway 暴露 |
| 状态源 | Blackboard Database + Artifact Store |
| 隔离边界 | 项目级 Container / VM + 网络与权限策略 |

## 1. 项目背景与问题定义

### 1.1 当前系统的主要问题

- 长对话、扫描结果和工具输出不断进入模型上下文，导致 Token 消耗持续增长。
- 事实、猜测、失败尝试和原始证据混在消息历史中，Compact 后容易失真。
- 多个 Agent 默认并行时，容易重复扫描、重复读取文件和重复尝试相同 Payload。
- 固定的 Web/Pwn/Crypto/Reverse 分类可能锁死后续路线，而实战任务经常跨方向演化。
- LangGraph 的静态节点与条件边适合确定性流程，但开放式安全探索需要动态生成任务图。
- Agent 会话、运行容器、任务生命周期、授权策略和项目状态边界不够明确。
- Observer 按固定轮次介入不能准确反映任务是否真正失去进展。

### 1.2 Aurora v2 的目标

Aurora v2 的目标不是堆叠更多 Agent，而是构建一个能够在授权范围内持续产生、验证和收敛安全假设的任务系统。

- 以 Fact–Intent 图表达“已经知道什么、为什么知道、下一步要做什么”。
- 以 Codex 作为受控 Worker 的执行内核，复用成熟 Agent Loop、工具调用与流式事件。
- 以统一 MCP Tool Gateway 向 Worker 提供跨 Web、Pwn、Reverse、Crypto、取证等能力。
- 允许 Solver 在同一会话内跨方向调用工具，同时在需要并行或隔离时提出 Fork 建议。
- 由 Scheduler 而非 Solver 最终决定 Fork、并发、重试、暂停与终止。
- 以 Artifact Store 保存完整原始证据，以黑板保存结构化状态，以检索构建运行时上下文。
- 以事件驱动 Observer 发现重复、偏航、冲突、风险和无进展。

### 1.3 非目标

- 不把模型 Prompt 当作安全边界。
- 不默认让多个 Solver 竞争解决同一个完全相同的 Intent。
- 不把所有工具描述一次性塞入每个 Worker 的上下文。
- 不让不同 Worker 容器默认直接互联或直接修改主数据库。
- 不把 Codex Thread、AGENTS.md 或单一 summary.md 当作项目权威状态。
- MVP 阶段不引入图数据库、MCTS 或大规模分布式调度。


---

## 2. 核心架构决策

| 编号 | 决策 | 说明 |
| --- | --- | --- |
| D-01 | 不使用 LangGraph 进行全局编排 | 由数据库状态机、事件总线和 Scheduler 驱动 Fact–Intent 图。 |
| D-02 | Codex 是执行平面，不是全局控制器 | Codex 负责一个 Worker 会话内的推理与工具循环。 |
| D-03 | Blackboard 是项目状态源 | 事实、假设、任务、尝试、证据和结论均落入结构化存储。 |
| D-04 | 所有 Worker 可见工具统一 MCP 化 | 包括 Shell、文件、浏览器、网络、安全工具、黑板和 Artifact 能力。 |
| D-05 | 工具动态暴露，而非全部同时暴露 | Worker 可申请跨域能力，Policy Engine 决定是否授权。 |
| D-06 | Manager/Observer/Solver 是角色，不直接等同于进程 | 角色由 Agent Profile 定义，执行时由 Worker Runtime 承载。 |
| D-07 | Solver 可建议 Fork，Scheduler 最终决策 | 避免 Solver 无限扩张任务和 Token。 |
| D-08 | Observer 事件触发为主、周期触发为辅 | 不以固定 Assistant Round 作为唯一判断依据。 |
| D-09 | 原始证据不可破坏性 Compact | 完整结果写入 Artifact，模型上下文只按需选择。 |
| D-10 | Worker 默认通过黑板协作 | 不同容器不直接通信，必要工具服务通过受控项目网络连接。 |

## 3. 术语与职责边界

| 术语 | 定义 | 主要职责 |
| --- | --- | --- |
| Agent Profile | 静态行为配置 | 模型、Prompt、初始能力、工具策略、输出 Schema、上下文模板。 |
| Worker | Agent Profile 的一次受控运行实例 | 承载 Thread、Sandbox、Intent、预算、租约、心跳和日志。 |
| Solver | 执行具体探索任务的 Agent 角色 | 调用 MCP 工具完成一个 Intent，返回证据与结构化结果。 |
| Manager / Reasoner | 全局规划 Agent 角色 | 读取黑板、判断进展、提出 Intent 与优先级，不直接启动进程。 |
| Observer | 审查与纠偏 Agent 角色 | 检测重复、偏航、无进展、冲突与高风险行为。 |
| Scheduler | 确定性控制组件 | Claim、Lease、分配 Worker、预算、并发、Fork、重试和回收。 |
| Blackboard | 项目结构化状态层 | Fact、Intent、Attempt、Hypothesis、Hint、Finding 等。 |
| Artifact Store | 原始证据层 | 终端输出、请求响应、文件、PCAP、截图、脚本和 Rollout。 |
| MCP Tool Gateway | 统一能力总线 | 工具注册、动态暴露、权限校验、审计、超时和结构化输出。 |
| Harness | 控制框架与运行外壳 | 连接 UI、调度、状态、容器、Codex、MCP 和安全策略。 |

### 3.1 Agent 与 Worker 的准确关系

```text
Scheduler
  ├─ 选择 Agent Profile
  ├─ 创建 Worker Instance
  ├─ 分配 Intent / Lease / Budget
  └─ 启动 Codex Thread

Agent Profile
  └─ 决定 Worker 如何思考、初始看到哪些工具、输出什么格式

Worker Runtime
  └─ 决定 Agent 在什么容器中、运行多久、可消耗多少资源
```

因此不能简单描述为“Agent 调用 Worker”。更准确的表达是：Scheduler 创建 Worker，Worker 加载 Agent Profile，并在 Codex Agent Loop 中执行当前 Intent。

## 4. 总体系统架构

```text
┌────────────────────────────────────────────────────────────┐
│                      Web UI / CLI / API                    │
│               项目创建、Hint、审批、状态展示              │
└────────────────────────────┬───────────────────────────────┘
                             │
┌────────────────────────────▼───────────────────────────────┐
│                        Aurora Daemon                      │
│ ProjectManager / Manager / Observer / Scheduler           │
│ BlackboardManager / PolicyEngine / BudgetManager          │
└───────────────┬───────────────────────┬────────────────────┘
                │                       │
┌───────────────▼──────────────┐  ┌─────▼────────────────────┐
│ Blackboard Database         │  │ Artifact Store           │
│ Fact / Intent / Attempt     │  │ Logs / HTTP / Binary     │
│ Hypothesis / Hint / Finding │  │ PCAP / Scripts / Trace   │
└───────────────┬──────────────┘  └─────┬────────────────────┘
                │                       │
┌───────────────▼───────────────────────▼────────────────────┐
│                     Runtime Manager                       │
│ Container/VM / Network Namespace / Resource Limits        │
└────────────────────────────┬───────────────────────────────┘
                             │ JSON-RPC / RPC
┌────────────────────────────▼───────────────────────────────┐
│                 Codex App Server / Worker Runtime          │
│ Thread / Turn / Item / Agent Loop / Event Stream          │
└────────────────────────────┬───────────────────────────────┘
                             │ MCP
┌────────────────────────────▼───────────────────────────────┐
│                      MCP Tool Gateway                      │
│ Registry / Capability / Policy / Approval / Audit         │
└──────────┬──────────┬──────────┬──────────┬───────────────┘
           ▼          ▼          ▼          ▼
         Web        Binary     Crypto    Forensic / General
        Tools        Tools      Tools         Tools
```


---

### 4.1 五个系统平面

| 平面 | 职责 | 代表组件 |
| --- | --- | --- |
| 控制平面 | 决定下一步、谁执行、能否并行和何时结束 | Manager、Observer、Scheduler、BudgetManager |
| 状态平面 | 保存当前项目权威状态和因果关系 | Blackboard Database |
| 执行平面 | 执行单个 Intent 的模型与工具循环 | Codex App Server、Worker |
| 能力平面 | 向 Worker 提供可审计、可授权的工具 | MCP Tool Gateway |
| 证据与隔离平面 | 保存原始证据并限制执行边界 | Artifact Store、Container/VM、Policy Engine |


---

## 5. Fact–Intent 图与黑板

### 5.1 为什么采用 Cairn 风格图架构

传统工作流图预先定义节点和边，而安全实战中后续方向往往由执行结果决定。Fact–Intent 图将流程变化转化为数据变化：Fact 表示已知事实，Intent 表示待验证方向，Worker 执行 Intent 后再产生新 Fact 或新建议。

```text
Goal
  ↓
Fact ──supports──> Intent ──executed_by──> Attempt
  ↑                                      │
  └────────────produced_by───────────────┘

Fact 还可以：CONTRADICTS / SUPERSEDES / SUPPORTS Hypothesis
```

### 5.2 节点与边

| 对象 | 含义 | 典型字段 |
| --- | --- | --- |
| Fact | 有证据支持的原子事实 | statement、confidence、evidence_refs、status |
| Hypothesis | 待验证的推测 | supporting_facts、contradicting_facts、status |
| Intent | 一个可执行的明确目标 | objective、capabilities、priority、lease |
| Attempt | Worker 的一次实际执行 | thread、turn、result、artifacts、cost |
| Artifact | 不可丢失的原始证据 | path、hash、type、summary、sensitivity |
| Finding | 可交付结论或漏洞 | severity、reproduction、evidence_refs |
| Hint | 用户或外部系统注入信息 | content、source、consumed |


---

| 关系 | 含义 |
| --- | --- |
| SUPPORTS | Fact 支持 Hypothesis 或 Intent。 |
| DEPENDS_ON | Intent 执行依赖某些 Fact 或其他 Intent。 |
| PRODUCED_BY | Fact 或 Artifact 由某次 Attempt 产生。 |
| CONTRADICTS | 事实或证据彼此冲突。 |
| SUPERSEDES | 新 Fact 替代过期 Fact。 |
| SUGGESTS | Attempt 建议创建新的 Intent。 |

### 5.3 不需要图数据库

MVP 可使用 PostgreSQL/SQLite 的普通表和关联表。查询可执行 Intent、依赖关系和相关 Fact 并不要求 Neo4j。只有在图规模、可视化和复杂路径查询明显成为瓶颈后再评估图数据库。

## 6. 上下文管理与 Compact

### 6.1 设计结论

项目仍然需要 Compact，但 Compact 不再表示“把所有历史压缩成一段摘要”。正确做法是：原始证据完整保留，黑板结构化保存，运行时上下文按 Intent 检索和组装。

```text
Codex 原生 Compact：单个 Thread 的窗口兜底
Blackboard Retrieval：项目级长期上下文管理
Artifact Store：不可丢失的原始证据
```

### 6.2 三层上下文

1. 原始证据层：完整命令输出、HTTP 请求响应、二进制、反编译结果、PCAP、截图和 Codex Item。
2. 结构化状态层：Fact、Hypothesis、Intent、Attempt、Finding，以及 Artifact 引用。
3. 运行时上下文层：为当前 Intent 临时生成的目标、相关事实、失败记录、证据摘要、权限和输出协议。

### 6.3 Context Builder

```text
WorkerContext =
  Project Goal
+ Current Intent
+ Authorization Scope
+ Direct Dependency Facts
+ Related Hypotheses
+ Related Failed Attempts
+ Selected Artifact Summaries
+ Recent Critical Events
+ Tool Capability Policy
+ Output Schema
```

Context Builder 不应把完整黑板、全部工具 Schema 或所有历史消息发给模型。其目标是保证关键事实召回率，同时保持输入长度相对稳定。

### 6.4 信息不丢失的保障

- 工具输出超过阈值后自动落盘，并返回 Artifact ID。
- Fact 必须携带 evidence_refs；无证据结论默认进入 Hypothesis。
- Fact Candidate 写入前执行 Schema、去重、冲突和范围校验。
- 高价值 Artifact 保存哈希、执行命令、工作目录、返回码和时间。
- 允许 Worker 按 Artifact ID 重新读取关键片段，而不是依赖摘要记忆。
- 定期评估 Compact 后的关键事实召回率和错误事实比例。

## 7. Manager–Observer–Solver 架构

### 7.1 Manager / Reasoner

- 读取项目级 Compact Context。
- 判断目标是否完成或是否阻塞。
- 提出新的 Intent、依赖关系、优先级和建议并发度。
- 汇总不同方向的 Fact，识别跨领域攻击链。
- 只提出计划，不直接修改授权、不直接启动 Worker。

Manager 不“存放 Memory/Idea”。长期状态必须写入 Blackboard；Manager 可以生成结构化 Idea/Hypothesis，但自身会话不是权威存储。

### 7.2 Observer

Observer 是事件驱动审查角色，不是每固定六轮强制插话的聊天参与者。其输出是结构化建议，由 Scheduler 或 Manager 应用。

| 触发类别 | 示例 |
| --- | --- |
| 重复 | 相同命令、相同 Payload 或等价 Intent 连续出现。 |
| 无进展 | 连续多次 Attempt 无新增 Fact 或 Artifact。 |
| 偏航 | 工具调用与当前 Intent 相关性过低。 |
| 冲突 | 新 Fact 与已有 ACTIVE Fact 矛盾。 |
| 风险 | 即将访问范围外目标、执行高风险操作或扩大权限。 |
| 预算 | Intent Token/时间/工具调用即将超限。 |
| 关键节点 | 出现候选 Flag、凭据、可利用漏洞或新的攻击面。 |

```text
ObserverDecision:
  CONTINUE | REDIRECT | REQUEST_EVIDENCE | FORK | PAUSE | STOP | ESCALATE
```

周期检查仍可作为兜底，例如每若干有效 Attempt 或每消耗一定 Token 触发，但不以 Assistant Round 数量作为核心指标。

### 7.3 Solver

- 接收一个明确 Intent。
- 根据当前任务制定局部 Todo。
- 自主选择当前可见 MCP 工具。
- 发现跨领域线索时申请新 Capability。
- 保存 Artifact 并返回 Fact Candidate、失败原因和建议 Intent。
- 可以建议 Fork，但不能自行无限创建 Worker。

### 7.4 Todo 的两层设计

| 层级 | 维护者 | 作用 | 持久化 |
| --- | --- | --- | --- |
| 项目级 Intent DAG | Manager + Scheduler | 全局待办、依赖、优先级和并发 | Blackboard |
| Solver 局部 Todo | 当前 Solver | 完成单个 Intent 的短期执行步骤 | Attempt 日志，可在完成后归档 |


---

## 8. Worker Runtime

### 8.1 Worker 的定义

Worker 是由 Scheduler 创建、加载 Agent Profile、在指定 Sandbox 中执行单个 Intent 的运行实例。Worker 不是领域知识本身，也不是全局调度器。

```text
Worker
├─ worker_id / project_id / intent_id
├─ agent_profile_id
├─ codex_thread_id / current_turn_id
├─ sandbox_id
├─ capability_set
├─ lease / heartbeat
├─ token / time / tool-call budget
├─ status
└─ event and artifact bindings
```

### 8.2 Worker 生命周期

```text
IDLE
  → CLAIMED
  → STARTING
  → RUNNING
  → CONCLUDING
  → COMPLETED

异常：RUNNING → TIMEOUT/CRASH/INVALID_OUTPUT
                 → CONCLUDING
                 → RETRYABLE 或 FAILED
```

Conclude 必须复用原 Thread，且不再开展新探索，只整理已经产生的事实、失败原因和 Artifact，减少前期 Token 浪费。


---

### 8.3 Worker 类型与 Agent Profile

| Worker Runtime | 可加载的 Agent Profile | 权限特点 |
| --- | --- | --- |
| Reasoner Worker | Manager / Reasoner | 主要读黑板、提议 Intent，不开放高风险执行工具。 |
| Review Worker | Observer | 读取 Attempt、事件指纹和 Fact 冲突，输出审查决策。 |
| Solver Worker | General / Web / Pwn / Reverse / Crypto / Misc | 可按需申请跨域 MCP 能力。 |
| Conclude Worker | Conclude Profile | 仅总结当前 Thread 已有结果。 |
| Evidence Worker | Evidence Extractor | 把工具与 Agent 输出转成 Fact Candidate。 |

## 9. 统一 MCP 工具总线

### 9.1 设计目标

Aurora v2 采用“Worker 可见能力全部 MCP 化”的原则。Worker 不直接感知底层 CLI、远程服务或宿主接口，所有业务工具均通过 MCP Tool Gateway 注册和调用。底层工具仍可运行在项目容器中，但其输入、输出、权限和审计由 Gateway 统一处理。

```text
Worker / Codex MCP Client
          │
          ▼
MCP Tool Gateway
├─ Tool Registry
├─ Capability Resolver
├─ Policy Enforcement
├─ Approval
├─ Timeout / Rate Limit
├─ Output Normalizer
├─ Artifact Extractor
└─ Audit Log
          │
          ├─ Core MCP: shell / files / artifact / blackboard
          ├─ Web MCP: http / browser / fuzz / upload / proxy
          ├─ Binary MCP: identify / checksec / gdb / ghidra / pwntools
          ├─ Crypto MCP: sage / z3 / transform / decode
          └─ Forensic MCP: tshark / binwalk / exif / stego
```

### 9.2 为什么不能一次暴露全部工具

- 大量 Tool Schema 会占用上下文。
- 相似工具过多会降低模型选择准确率。
- 无关工具扩大误调用和越权面。
- 部分工具需要专用容器、VM 或网络。

因此“所有工具 MCP 化”与“所有工具同时可见”必须分开。系统支持全部能力，但每个 Worker 只加载与当前 Intent 相关的工具子集。

### 9.3 动态能力授权

```text
1. Worker 获得基础工具：blackboard、artifact、project、capability.request
2. Scheduler 根据 Intent capability_tags 下发初始工具集
3. Solver 发现新方向，调用 capability.request
4. Policy Engine 检查范围、风险、预算、环境和重复度
5. Gateway 更新当前 Thread 可用工具
6. Solver 保持原会话继续，或由 Scheduler 决定 Fork
```

### 9.4 工具封装粒度

不应为每个 CLI 参数创建一个 MCP Tool。优先按照稳定语义动作封装，同时保留受控的通用 Shell 能力。

| 推荐 Tool | 底层可能实现 |
| --- | --- |
| network.scan | nmap / masscan 的受控模式 |
| http.request | curl / requests / HTTP client |
| web.enumerate | ffuf / dirsearch |
| binary.inspect | file / strings / checksec |
| debugger.execute | gdb / pwndbg |
| reverse.analyze | Ghidra Headless / radare2 |
| crypto.solve | Python / SageMath / z3 |
| forensic.inspect | tshark / binwalk / exiftool |
| sandbox.exec | 通用受限命令执行逃生工具 |

### 9.5 统一 MCP 输出协议

```text
{
  "success": true,
  "summary": "发现 80 和 8080 端口开放",
  "findings": [...],
  "artifact_refs": ["artifact-nmap-001"],
  "metrics": {
    "duration_ms": 6321,
    "exit_code": 0,
    "output_bytes": 14892
  },
  "warnings": []
}
```

大型原始输出必须写入 Artifact Store。模型只获取摘要、关键片段和 Artifact 引用，需要时再通过 artifact.read 精确读取。

## 10. 跨方向协作与 Fork 决策

### 10.1 同一 Worker 跨方向执行

当新方向与当前攻击链紧密相关、规模较小且不适合并行时，当前 Solver 申请新 MCP Capability 后继续执行。例如 Web 下载 ELF 后快速调用 binary.inspect 与 reverse.analyze。

### 10.2 创建新 Worker

当方向可以并行、需要大量独立上下文、需要不同模型或特殊 VM、或者当前 Worker 接近预算上限时，Solver 提交 Fork 建议。

```text
SolverForkProposal
├─ reason
├─ suggested_intent
├─ capability_tags
├─ dependency_fact_ids
├─ expected_cost
└─ artifact_refs
```


---

### 10.3 Scheduler 决策条件

| 维度 | 判断 |
| --- | --- |
| 依赖性 | 新任务是否必须等待当前任务结果。 |
| 并行收益 | 并行能否显著缩短关键路径。 |
| 上下文独立度 | 新方向是否需要大量不同信息。 |
| 重复度 | 是否已有相同或高度相似 Intent。 |
| 预算 | 项目和 Intent 是否有足够 Token、时间和工具调用额度。 |
| 隔离要求 | 是否需要特殊容器、VM、网络或模型。 |
| 风险 | 是否扩大授权或引入高风险操作。 |

### 10.4 Worker 之间如何协作

Worker 默认不直接通信。跨 Worker 协作通过 Blackboard 与 Artifact Store 完成，从而保证可恢复、可审计和可去重。

```text
Worker A → Fact / Artifact → Blackboard
                              ↓
                       Manager / Scheduler
                              ↓
                  Context Builder → Worker B
```

只有浏览器、Burp、Ghidra、靶场服务等工具级组件需要网络通信时，才在项目专属受控网络中开放相应服务。


---

## 11. Harness 与运行时管理

### 11.1 Harness 组成

```text
AuroraDaemon
├─ ConfigManager
├─ ProjectManager
├─ BlackboardManager
├─ ArtifactManager
├─ ManagerService
├─ ObserverService
├─ Scheduler
├─ RuntimeManager
├─ MCPGatewayManager
├─ PolicyEngine
└─ BudgetManager
```

### 11.2 Host 与 Sandbox 通信

宿主控制面与项目容器通过受限 RPC/JSON-RPC 通信。容器不得直接访问主数据库，而应通过有限的 Blackboard、Artifact、Heartbeat 和 Approval 接口交互。

| 方向 | 允许内容 |
| --- | --- |
| Host → Worker | 创建/恢复 Thread、下发 Intent、工具配置、预算、取消和审批结果。 |
| Worker → Host | 事件、心跳、MCP 请求、Artifact 元数据、结构化结果和 Fork 建议。 |
| 禁止 | 任意数据库连接、宿主 Docker Socket、未授权文件挂载和任意控制面命令。 |

### 11.3 RuntimeManager

- 为每个 Project 创建持久工作区和隔离执行环境。
- 根据任务选择 Container 或临时 VM。
- 管理 Codex App Server、MCP Server 和工具服务进程。
- 设置 CPU、内存、磁盘、PID、网络和运行时限制。
- 执行销毁、归档和崩溃恢复。

## 12. 核心执行流程

### 12.1 项目启动

```text
Create Project
  → Validate Authorization Scope
  → Create Sandbox and Artifact Namespace
  → Write Goal / Hint / Origin Fact
  → Create Bootstrap Intent
  → Scheduler dispatches Bootstrap Solver
```

### 12.2 Reason–Explore 循环

```text
1. Manager 读取项目级 Compact Context
2. 目标未完成时提出候选 Intent
3. Result Processor 去重、校验依赖和授权
4. Scheduler Claim 可运行 Intent
5. 创建 Worker，加载 Agent Profile 和 MCP 工具集
6. Worker 执行并持续产生 Event / Artifact
7. Observer 按事件判断是否需要介入
8. Worker 返回结构化结果或进入 Conclude
9. 写入 Fact / Attempt / Artifact / Suggested Intent
10. Flag Validator 与 Goal Checker 判断是否结束
```

### 12.3 Intent Lease

Intent 的领取必须是原子操作。Worker 通过 Heartbeat 续租；超时后 Scheduler 回收 Intent，并根据已有 Artifact 决定 Conclude、Retry 或 Fail。

### 12.4 结构化 Worker 输出

```text
{
  "status": "success | partial | failed",
  "summary": "...",
  "fact_candidates": [...],
  "hypotheses": [...],
  "artifact_refs": [...],
  "failed_attempts": [...],
  "suggested_intents": [...],
  "fork_recommendations": [...],
  "candidate_flags": [...]
}
```

## 13. 数据模型

### 13.1 Project

```text
Project:
  id, name, goal, challenge_type, status
  authorization_scope_id, sandbox_id
  token_budget, time_budget, tool_call_budget
  created_at, updated_at
```

### 13.2 Fact

```text
Fact:
  id, project_id, statement, category
  confidence, evidence_refs
  source_intent_id, source_attempt_id
  status: ACTIVE | SUPERSEDED | DISPUTED | RETRACTED
  supersedes, created_at
```

### 13.3 Intent

```text
Intent:
  id, project_id, objective, capability_tags
  dependency_fact_ids, parent_intent_id
  priority, risk_level
  status: PENDING | CLAIMED | RUNNING | CONCLUDING |
          COMPLETED | FAILED | BLOCKED | CANCELLED
  lease_owner, lease_expires_at
  retry_count, max_retries, budget
```

### 13.4 Attempt 与 Worker

```text
Attempt:
  id, intent_id, worker_id
  codex_thread_id, codex_turn_id
  status, result_summary, failure_reason
  artifact_refs, token_usage, tool_calls
  started_at, finished_at

Worker:
  id, project_id, intent_id, agent_profile_id
  sandbox_id, capability_set, status
  lease, heartbeat, budgets
```

### 13.5 Artifact

```text
Artifact:
  id, project_id, source_attempt_id
  type, path, sha256, mime_type, size
  summary, sensitivity, created_at
```

## 14. Intent 优先级与预算

### 14.1 初始评分模型

```text
priority =
  2.0 * goal_relevance
+ 1.5 * information_gain
+ 1.5 * prerequisite_satisfaction
+ 1.0 * exploitability
+ 0.8 * novelty
- 1.2 * execution_cost
- 1.5 * risk
- 1.5 * duplication
```

### 14.2 预算层级

| 层级 | 限制 |
| --- | --- |
| Project | 总 Token、总时间、最大并发、最大 Intent 数。 |
| Intent | 最大 Token、时间、工具调用、重试次数。 |
| Worker | 单 Turn Token、空闲超时、输出大小和资源额度。 |
| Tool | 单次超时、调用频率、目标范围和结果大小。 |

### 14.3 需要持续记录的效率指标

- 每条新 Fact 的 Token 成本。
- 重复 Intent 和重复工具调用比例。
- 无新增 Fact 的 Attempt 比例。
- Observer 介入后成功率和额外成本。
- Fork 带来的关键路径缩短与额外 Token。
- 不同 Agent Profile 的有效发现率。


---

## 15. 安全与授权

### 15.1 授权范围

```text
AuthorizationScope:
  allowed_hosts / domains / ports / protocols
  allowed_actions
  expires_at
  max_request_rate
  deny_metadata_and_management_networks
```

### 15.2 MCP Tool 权限状态

```text
HIDDEN      当前 Worker 不可发现
REQUESTABLE 可通过 capability.request 申请
AUTO         策略校验后自动执行
APPROVAL     需要人工或上级审批
DENIED       强制拒绝
```

### 15.3 隔离要求

- 不挂载宿主 Docker Socket。
- 默认非 root、非 privileged。
- 项目工作区最小化挂载。
- 所有网络出口经过授权校验和审计。
- DNS 解析、重定向和代理后的最终地址再次验证。
- 恶意二进制、内核或高风险 Pwn 场景优先使用临时 VM。
- Worker 不能修改 Policy Engine、预算或授权范围。

## 16. Codex 集成边界

### 16.1 保留

- Agent Loop。
- App Server JSON-RPC 集成边界。
- Thread / Turn / Item 事件模型。
- 流式事件、审批请求和执行日志。
- ThreadStore 作为回放与崩溃恢复来源。
- Codex 原生 Compact 作为线程窗口兜底。

### 16.2 替换或外置

- 项目级状态：移入 Blackboard。
- 全局调度：移入 Scheduler。
- 长期证据：移入 Artifact Store。
- 工具权限与动态暴露：移入 MCP Tool Gateway。
- 安全边界：移入外层 Container/VM 与 Policy Engine。
- 默认编程 Prompt：替换为 Manager、Observer、Solver、Conclude 等 Profile。

### 16.3 不优先 Fork Codex

第一阶段通过 App Server 与 MCP 完成外部集成。只有在缺少必要生命周期钩子、事件类型或 Sandbox 接口时，才对 Codex 做窄范围补丁，避免长期维护大型 Fork。


---

## 17. 推荐目录结构

```text
aurora/
├─ apps/
│  ├─ api/
│  ├─ daemon/
│  ├─ tui/
│  └─ web/
├─ core/
│  ├─ models/
│  ├─ schemas/
│  ├─ state_machine/
│  └─ events/
├─ blackboard/
│  ├─ repository/
│  ├─ graph_query/
│  ├─ fact_merger/
│  └─ conflict_detector/
├─ orchestration/
│  ├─ manager/
│  ├─ observer/
│  ├─ scheduler/
│  ├─ lease/
│  └─ budget/
├─ workers/
│  ├─ profiles/
│  ├─ runtime/
│  ├─ lifecycle/
│  ├─ context_builder/
│  └─ result_processor/
├─ codex_client/
│  ├─ app_server/
│  ├─ protocol/
│  ├─ thread_manager/
│  └─ event_mapper/
├─ mcp_gateway/
│  ├─ registry/
│  ├─ capability/
│  ├─ policy/
│  ├─ audit/
│  └─ servers/
│     ├─ core/
│     ├─ web/
│     ├─ binary/
│     ├─ crypto/
│     └─ forensic/
├─ artifact/
├─ sandbox/
├─ policy/
├─ tests/
└─ docs/
```

## 18. 技术选型

| 模块 | 建议 |
| --- | --- |
| 主控制层 | Python + FastAPI + asyncio + Pydantic |
| 数据库 | MVP：SQLite；稳定阶段：PostgreSQL |
| 队列/租约 | MVP：数据库事务；稳定阶段：Redis 或消息队列 |
| Artifact | MVP：本地目录；稳定阶段：MinIO/S3 |
| Worker Runtime | Codex App Server |
| 工具协议 | MCP Tool Gateway |
| 隔离 | Docker/Podman；高风险任务使用 VM |
| 全局编排 | 自研事件循环与状态机，不使用 LangGraph |

## 19. MVP 与迭代计划

| 阶段 | 目标 | 验收 |
| --- | --- | --- |
| P0 协议验证 | Python 控制 Codex App Server，完成 Thread/Turn/Event/MCP 调用 | 可执行一个文件分析 Intent 并保存事件。 |
| P1 黑板 MVP | Project/Fact/Intent/Attempt/Artifact 数据模型 | 不依赖完整聊天历史完成简单任务。 |
| P2 Scheduler | Claim/Lease/Heartbeat/Timeout/Conclude/Retry | 杀死 Worker 后可回收并保留已有结果。 |
| P3 MCP Gateway | 基础 Tool Registry、动态能力和统一输出 | 同一 Solver 可从 Web 工具申请 Binary 工具。 |
| P4 Manager/Observer | 动态生成 Intent、事件驱动纠偏 | 减少重复 Attempt，并可结构化 Redirect/Fork。 |
| P5 隔离与授权 | 项目容器、出口策略、审批和资源配额 | 无法访问未授权目标和宿主敏感资源。 |
| P6 多 Worker 协作 | 并发 Intent、Artifact 共享、Fork 决策 | 跨 Web/Reverse/Pwn 攻击链可协作完成。 |
| P7 UI 与评估 | Fact–Intent 图、实时事件、成本面板 | 可观察、可回放、可比较策略效率。 |

## 20. 测试与评估

### 20.1 单元与集成测试

- Fact 去重、冲突和 supersedes。
- Intent 状态迁移、Lease 过期和原子 Claim。
- Context Builder Token 限制与关键事实召回。
- MCP Tool Schema、权限、超时和 Artifact 生成。
- Codex Event 到 Attempt/Artifact 的映射。
- Observer 重复指纹和无进展触发。
- Fork 建议去重与预算决策。


---

### 20.2 A/B 评估

Observer 和多 Worker 并发是否提高效率不能只靠直觉，需要在相同题集和模型配置下比较：

| 实验组 | 策略 |
| --- | --- |
| A | 单 Solver，无 Observer。 |
| B | 单 Solver，固定周期 Observer。 |
| C | 单 Solver，事件驱动 Observer。 |
| D | 事件驱动 Observer + 按需 Fork。 |

- Flag 成功率。
- 平均求解时间和总 Token。
- 重复工具调用与重复 Intent。
- 错误 Fact 与人工介入次数。
- Fork 的有效并行收益。

## 21. 主要风险与应对

| 风险 | 应对 |
| --- | --- |
| 黑板持续膨胀 | 原子 Fact、去重、supersedes、相关子图检索和旧 Attempt 归档。 |
| 所有工具 MCP 化开发量过大 | 先实现统一 Gateway 与高频语义工具，再逐步覆盖长尾 CLI。 |
| 工具 Schema 过多 | 按 Capability 动态暴露、分组加载和 capability.request。 |
| 模型错误写入 Fact | Fact Candidate 校验、证据强制、低置信度进入 Hypothesis。 |
| Solver 无限 Fork | 只能提出建议，Scheduler 负责预算、去重和最终决策。 |
| Observer 反而增加成本 | 事件触发、冷却、结构化输出和 A/B 评估。 |
| Codex 上游变化 | 以 App Server 协议为边界，兼容层和固定回归测试。 |
| 安全工具越权 | MCP Gateway 与 Sandbox 双重校验，最小权限和完整审计。 |


---

## 22. 架构决策记录（ADR）

| ADR | 决定 |
| --- | --- |
| ADR-001 | 全局编排不使用 LangGraph。 |
| ADR-002 | 采用 Cairn 风格 Fact–Intent 图，但自行实现Aurora数据模型和调度。 |
| ADR-003 | Codex 是 Worker Runtime，Blackboard 是项目状态源。 |
| ADR-004 | 所有 Worker 可见执行能力统一经 MCP Tool Gateway。 |
| ADR-005 | 工具动态暴露，Worker 可跨域申请 Capability。 |
| ADR-006 | Manager/Observer/Solver 由 Agent Profile 定义，Worker 承载运行。 |
| ADR-007 | Solver 只建议 Fork，Scheduler 最终决策。 |
| ADR-008 | Observer 使用事件触发为主的审查机制。 |
| ADR-009 | Worker 默认通过黑板和 Artifact 间接协作。 |
| ADR-010 | 原始证据永久保存，Compact 只作用于模型输入。 |

## 23. 示例：跨 Web、Reverse、Pwn 的协作流程

```text
1. Bootstrap Solver 发现 /download 接口，产生 Fact：可下载未知文件。
2. Web Solver 下载 app.bin，http.response 与文件保存为 Artifact。
3. Worker 调用 binary.inspect MCP，确认是 x86-64 ELF。
4. 当前 Solver 申请 reverse capability，快速 strings 分析发现隐藏参数。
5. 同时发现程序规模较大，提交 Fork Proposal：深入逆向 ELF。
6. Scheduler 检查预算与重复度，创建 Reverse Intent 和新 Worker。
7. 原 Web Worker 继续分析认证逻辑；Reverse Worker 读取相同 Artifact。
8. Reverse Worker 发现危险 strcpy，产生 Pwn Hypothesis 与 Fact Candidate。
9. Manager 创建 Pwn Intent；Scheduler 分配 Pwn Worker 和专用 VM。
10. Pwn Worker 通过 debugger.execute / pwn tools 验证利用并得到候选 Flag。
11. Flag Validator 校验，项目进入 COMPLETED。
```

## 24. 最终结论

Aurora v2 的最终形态不是一个由固定节点连接起来的 LangGraph 工作流，而是一个由事实、意图、证据和执行事件持续驱动的安全任务系统。

```text
Fact–Intent Blackboard
        +
Manager / Event-driven Observer / Solver
        +
Lease-based Scheduler
        +
Codex Worker Runtime
        +
Unified MCP Tool Gateway
        +
Artifact Evidence Store
        +
Project Container / VM and Authorization Policy
```

最重要的责任边界是：图决定当前存在什么任务，Manager 提出做什么，Scheduler 决定何时由谁执行，Agent Profile 决定 Worker 如何工作，MCP 提供能力，Policy Engine 决定能否执行，Blackboard 与 Artifact Store 保存协作结果。

## 附录 A：MVP 最小闭环

1. 创建 Project 和 Authorization Scope。
2. 写入 Goal、Hint 和 Bootstrap Intent。
3. Scheduler 原子 Claim Intent。
4. 创建 Worker，加载 Agent Profile。
5. 从 Blackboard 构建 Compact Context。
6. 通过 Codex App Server 启动 Thread/Turn。
7. 通过 MCP Gateway 调用一个或多个工具。
8. 保存 Codex Events 和完整 Artifact。
9. 解析 Worker 结构化结果并写入 Fact/Attempt。
10. Manager 生成下一个 Intent，或 Goal Checker 结束项目。

## 附录 B：设计输入

- Cairn：Fact–Intent 黑板、Dispatcher、Bootstrap/Reason/Explore 与任务租约思路。
- BreachWeave：Manager–Observer–Solver、Harness、Docker Solver Runtime 和纠偏机制思路。
- Codex：App Server、Agent Loop、Thread/Turn/Item、流式事件和 Worker 执行能力。
- MCP：统一模型工具协议、动态工具发现、结构化输入输出与能力网关。
- Aurora既有系统：CTF 专项能力、工具链、Flag 检查、反思与容器经验。
